# Phisher → Stremio Bridge

This is a starter Stremio addon project.

Important:
- The original Phisher CloudStream extensions are Kotlin/CloudStream extensions.
- They cannot be executed directly by Stremio.
- Each provider needs a Stremio-compatible adapter that returns stream objects.
- `index.js` currently exposes a valid Stremio manifest and an empty stream endpoint.
- Provider-specific adapters must be implemented before it can return actual movie/series sources.

## Run

```bash
npm install
npm start
```

Then open:

`/manifest.json`

## Next step

Add adapters only for providers whose implementation can legally and technically be adapted to Stremio's API.
