const express = require("express");
const app = express();
const PORT = process.env.PORT || 7000;

const manifest = {
  id: "com.phisher.bridge",
  version: "1.0.0",
  name: "Phisher Bridge",
  description: "Stremio bridge for compatible providers.",
  resources: ["stream"],
  types: ["movie", "series"],
  idPrefixes: ["tt"],
  catalogs: []
};

app.get("/", (req, res) => res.json(manifest));
app.get("/manifest.json", (req, res) => res.json(manifest));

app.get("/stream/:type/:id.json", (req, res) => {
  // Provider adapters must be added here. CloudStream Kotlin extensions
  // cannot be executed directly by Node/Stremio.
  res.json({ streams: [] });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Phisher Bridge running on port ${PORT}`);
});
